# Jelly Recess Light – Galaxy Test Icon Pack

이 프로젝트는 24개 테스트 아이콘을 Android 아이콘팩 APK로 빌드하기 위한 완성 프로젝트입니다.

## 포함
- 24개 PNG 아이콘
- 삼성 기본 앱 + KakaoTalk / Naver / Instagram / YouTube / Maps / Play Store / Photos 매핑
- appfilter.xml / drawable.xml
- Nova / ADW / Lawnchair / Smart Launcher 등의 일반 아이콘팩 인식 Intent
- GitHub Actions 자동 APK 빌드 설정

## 가장 쉬운 APK 만들기: GitHub Actions
1. ZIP 압축을 풉니다.
2. 새 GitHub 저장소에 폴더 내용을 그대로 올립니다.
3. GitHub 저장소의 Actions 탭으로 이동합니다.
4. Build Galaxy Test APK → Run workflow를 누릅니다.
5. 빌드가 끝나면 Jelly-Recess-Light-Test-APK artifact를 받습니다.
6. 안의 Jelly_Recess_Light_Test.apk를 갤럭시에 설치합니다.

## Android Studio
이 폴더를 열고 Build > Build App Bundle(s) / APK(s) > Build APK(s).
디버그 APK: app/build/outputs/apk/debug/app-debug.apk

## 갤럭시 적용
1. APK 설치
2. Good Lock → Theme Park
3. Icon → Create New
4. Icon pack
5. Third party icon packs
6. Jelly Recess Light Test 선택
7. 저장 → 적용

일부 삼성/서드파티 앱은 버전별 Activity 이름이 달라 자동 매칭이 안 될 수 있습니다. 그 경우 Theme Park에서 해당 앱 아이콘을 눌러 이 팩의 아이콘을 직접 선택하면 됩니다.

이 파일은 디자인 확인용 테스트 팩입니다. Galaxy Store 판매용 테마 패키지는 별도의 삼성 테마 제작/검수 절차가 필요합니다.
