# Jelly Recess V3 – Galaxy Test Icon Pack

24개 Jelly Recess V3 테스트 아이콘을 Android 아이콘팩 APK로 빌드하는 프로젝트입니다.

## 포함
- 24개 1024×1024 PNG 아이콘
- 삼성 기본 앱 + KakaoTalk / Naver / Instagram / YouTube / Maps / Play Store / Photos 매핑
- appfilter.xml / drawable.xml
- 일반 아이콘팩 인식 Intent
- GitHub Actions 자동 APK 빌드 설정

## GitHub에 프로젝트 내용을 풀어서 올린 경우
1. Actions 탭 → Build Jelly Recess V3 APK
2. Run workflow
3. 완료 후 Artifacts → Jelly-Recess-V3-Test-APK 다운로드
4. Jelly_Recess_V3_Test.apk 설치

## 갤럭시 적용
1. APK 설치
2. Good Lock → Theme Park
3. Icon → Create New
4. Icon pack → Third party icon packs
5. Jelly Recess V3 Test 선택
6. 저장 → 적용

일부 앱은 앱 버전에 따라 Activity 이름이 달라 자동 매칭되지 않을 수 있습니다. 그 경우 Theme Park에서 해당 앱 아이콘을 눌러 이 팩의 아이콘을 직접 선택하면 됩니다.

참고: V3의 Store/Chat/Video/Social/N 모양 테스트 심볼은 각각 Play Store/KakaoTalk/YouTube/Instagram/Naver 매핑용으로 사용했습니다. 디자인 테스트용입니다.
