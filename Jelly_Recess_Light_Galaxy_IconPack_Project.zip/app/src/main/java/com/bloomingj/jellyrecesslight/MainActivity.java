package com.bloomingj.jellyrecesslight;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 72, 48, 48);
        root.setGravity(Gravity.TOP);
        root.setBackgroundColor(Color.rgb(243, 247, 252));

        TextView title = new TextView(this);
        title.setText("Jelly Recess Light");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.rgb(32, 48, 64));

        TextView body = new TextView(this);
        body.setText(
            "\n24개 테스트 아이콘이 설치되었습니다.\n\n" +
            "갤럭시 적용 방법\n" +
            "1. Good Lock → Theme Park 실행\n" +
            "2. 아이콘(Icon) → 새로 만들기\n" +
            "3. 아이콘 팩(Icon pack) 선택\n" +
            "4. Third party icon packs에서\n" +
            "   Jelly Recess Light Test 선택\n" +
            "5. 저장 후 적용\n\n" +
            "일부 앱이 자동 매칭되지 않으면 Theme Park에서 해당 앱을 눌러 " +
            "이 팩의 아이콘을 직접 선택하면 됩니다."
        );
        body.setTextSize(17);
        body.setLineSpacing(8, 1.0f);
        body.setTextColor(Color.rgb(62, 77, 92));

        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
    }
}
